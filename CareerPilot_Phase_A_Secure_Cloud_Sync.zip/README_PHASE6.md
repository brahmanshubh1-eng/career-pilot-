# CareerPilot Phase 6 — Real SaaS Foundation

CareerPilot Phase 6 upgrades the Phase 5.1 Premium 90-day Coach into a production-oriented SaaS foundation.

### Customer experience
- Real account signup/sign-in with Supabase when configured.
- Cloud-synced assessment, career match, 90-day plan and daily progress.
- Daily execution remains usable offline/local-first.
- Customer can manually trigger cloud sync.

### Owner experience
- Customer progress dashboard removed from the app; customer activity remains private to the signed-in customer.
- The app does not expose customer rows, progress, revenue, or activity to an owner/admin UI.
- Supabase RLS prevents ordinary customers from reading other customers.

### Premium protection
A browser flag is not considered proof of paid Premium. Paid access must eventually be written by a verified server billing webhook.

See `PHASE6_SETUP.md` and `supabase-schema.sql`.
