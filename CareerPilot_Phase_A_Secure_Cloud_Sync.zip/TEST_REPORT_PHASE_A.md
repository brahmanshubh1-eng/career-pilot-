# CareerPilot Phase A test report

## Passed
- `node --check app.js`
- `node --check sw.js`
- `node --check api/coach.js`
- ZIP integrity (`unzip -t`)
- Static checks: session refresh, password reset request/update flow, cloud profile read/upsert, daily log read/upsert, owner delete policies, no service-role key in frontend config.
- Local headless Chromium smoke test of page startup/render (see below).

## Not yet verified
- Live Supabase signup/email confirmation and sign-in.
- Password recovery end-to-end with a real email.
- Cloud sync between two real devices/browsers against the configured Supabase project.
- Real Android/iOS device testing.
- Production deployment or Vercel Preview deployment.

The SQL schema must be run in Supabase before cloud sync will work. Automated syntax/static checks do not prove cloud security or remote configuration is correct.
