# CareerPilot Phase 6 — Real SaaS Setup

Phase 6 adds the production data model and cloud-sync boundary while retaining a local fallback.

## 1. Supabase
1. Create a Supabase project.
2. Run `supabase-schema.sql` in SQL Editor.
3. Enable Email authentication.
4. Put the project URL and **anon/public** key into `backend-config.json`.
5. Never put the service-role key in the browser.
6. Create your owner account and insert its auth UUID into `cp_admin_users`.

## 2. Deploy
Upload the complete project to Vercel. `backend-config.json` is safe to contain only the public Supabase URL/anon key. For production payment webhooks, secrets belong in Vercel environment variables/server functions.

## 3. Phase 6 behavior
- Customers can create/sign into a real Supabase account when configured.
- CareerPilot keeps working locally if cloud configuration is absent.
- Signed-in customer data can sync to their cloud profile.
- Daily execution logs are stored per customer/date.
- Admin view is restricted by the `cp_admin_users` table through RLS.
- Premium entitlement remains server-controlled; the browser must never be trusted to grant paid access.

## 4. Payments
Razorpay/Stripe checkout and webhook verification should be connected server-side next. Do not put secret payment keys in frontend code.
