# CareerPilot Phase 2

Product-experience upgrade of the Phase 1 production foundation.

Core loop: Assessment → Dashboard → Career Explorer → Skills → 90-day roadmap → Coach → Progress → Export/backup.
