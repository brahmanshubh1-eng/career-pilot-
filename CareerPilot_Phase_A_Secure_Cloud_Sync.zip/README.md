# CareerPilot — Launch-Ready Baseline

A mobile-first career exploration web app with a 15-question assessment, interest-aligned career matches, career detail pages, a 90-day roadmap, skill and daily-task tracking, Premium Coach experience, local backup/restore, report export/print, and installable PWA support.

## Deploy to Vercel
1. Extract this ZIP.
2. In Vercel, choose **Add New → Project** and import the folder/repository, or use Vercel's static project upload flow if available.
3. Keep the project root as the folder containing `index.html`, `app.js`, `vercel.json`, and `package.json`. No build command or output directory is required for the static frontend.
4. Deploy a **Preview** first. Test the assessment, results, roadmap, daily tasks, backup/restore, and mobile layout before promoting to production.
5. To enable live AI replies, add `OPENAI_API_KEY` in Project Settings → Environment Variables, then redeploy. Never put that secret in frontend files. API use may cost money.

## Data and feature status
- **Local-first:** assessment, results, roadmap, and progress save in this browser/device. Export a backup before clearing browser data.
- **Cloud accounts:** Supabase configuration is included, but cloud sync works only if the matching schema is installed and row-level security (RLS) policies are correct. Test sign-up, sign-in, refresh, and sync before depending on it.
- **Premium Coach:** the user-facing Coach, daily missions, and personalized plan are available. Live AI calls use `/api/coach` only when `OPENAI_API_KEY` is configured. The built-in/offline guidance is not live generative AI.
- **Payments:** no checkout/webhook implementation is connected in this baseline. Do not take paid subscriptions until server-side billing verification is built and tested.
- **Privacy:** this build does not include an admin dashboard for viewing customers' private progress.

## Validation
Run `npm run check` to syntax-check the JavaScript files. Then test the Preview URL on actual Android and desktop browsers. Automated syntax and logic checks are not a substitute for real-device testing.

## Next six priorities
See `NEXT_PHASE_PRIORITIES.md` for the planned sequence: secure authentication/cloud sync, database-backed progress, secure AI, resume/job matching, payments, and analytics/onboarding/QA.

Career guidance is exploratory and does not guarantee jobs, salary, or income.


## Phase A: secure accounts and cloud sync
See `README_PHASE_A.md` and `TEST_REPORT_PHASE_A.md`. This phase adds session refresh, password recovery, cloud restore/sync improvements, and owner-only cloud-data deletion. Run `supabase-schema.sql` in Supabase before testing cloud features. Cloud auth/sync and recovery must be tested against the live Supabase project before production use.
