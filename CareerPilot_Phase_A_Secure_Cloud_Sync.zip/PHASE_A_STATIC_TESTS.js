const fs = require('fs');
const app = fs.readFileSync('app.js', 'utf8');
const sql = fs.readFileSync('supabase-schema.sql', 'utf8');
const checks = {
  'password reset request': app.includes('/auth/v1/recover') && app.includes('cp6PasswordReset'),
  'recovery password update': app.includes('cp6UpdatePassword') && app.includes('/auth/v1/user'),
  'refresh-token session renewal': app.includes('grant_type=refresh_token') && app.includes('cp6RefreshSession'),
  'cloud profile pull and push': app.includes('/rest/v1/cp_profiles?select=*') && app.includes('resolution=merge-duplicates'),
  'daily-log pull and push': app.includes('/rest/v1/cp_daily_logs?select=*') && app.includes('cp_daily_logs?on_conflict=user_id,log_date'),
  'cloud data deletion is user-triggered': app.includes('cp6DeleteCloudData') && app.includes('if(!confirm('),
  'profile owner-only RLS': sql.includes('auth.uid() = user_id'),
  'owner delete policies': sql.includes('profile owner delete') && sql.includes('daily owner delete'),
  'updated_at triggers': sql.includes('cp_profiles_updated_at') && sql.includes('cp_daily_logs_updated_at'),
  'no service-role secret in browser config': !/service[_-]?role|SUPABASE_SERVICE_ROLE_KEY/i.test(fs.readFileSync('backend-config.json','utf8'))
};
for (const [name, ok] of Object.entries(checks)) console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`);
if (Object.values(checks).some(ok => !ok)) process.exit(1);
