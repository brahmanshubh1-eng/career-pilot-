# CareerPilot Phase A — Secure Accounts & Cloud Sync

## What changed
- Added session refresh on app startup and graceful local-only fallback when the session expires.
- Added email password-reset request and recovery-link password update flow.
- Added pull-before-push sync: when cloud data is newer (or local data is empty), CareerPilot restores it; otherwise local data is uploaded.
- Expanded the profile payload to include assessment answers/results and personal progress data.
- Verifies profile upsert and daily-log requests and displays sync errors rather than claiming success.
- Added an explicit “Delete my cloud data” action. It deletes this user's CareerPilot profile and daily logs only; it does not delete the Supabase login account or the local device copy.
- Updated the SQL schema with authenticated-user-only RLS policies, owner-only delete policies, and updated_at triggers. Policies are safe to re-run for the named CareerPilot policies.
- Kept paid Premium server-controlled. This phase does not activate paid access or add payments.

## Required Supabase setup
1. Open Supabase → SQL Editor for the configured project.
2. Review and run `supabase-schema.sql`. It creates/updates the `cp_profiles`, `cp_daily_logs`, and `cp_admin_users` tables and the listed policies/triggers.
3. In Authentication → URL Configuration, set the Site URL to your deployed CareerPilot URL and add that URL to the Redirect URLs allowlist. Password recovery redirects to the current app path.
4. In Authentication → Providers, enable Email. Choose whether email confirmation is required.
5. In Project Settings → API, confirm `backend-config.json` contains only the project URL and publishable/anon key. Never use the service-role key in browser code.
6. Deploy to a Vercel Preview first. Create a test account and verify email confirmation, sign-in, password recovery, manual sync, a second browser/device, sign-out, and cloud-data deletion.

## Data safety notes
- CareerPilot keeps a local copy in this browser. Cloud sync requires the SQL schema and Supabase Auth configuration to be correct.
- Cloud data deletion is not account deletion. Supabase Auth account deletion requires a trusted server-side admin function and is intentionally not performed by the browser.
- The SQL schema cannot be applied remotely by this ZIP; the project owner must run it in the Supabase SQL Editor.
- This build has not been verified against the live Supabase project or a physical phone as part of this change. Do not treat static tests as proof of live authentication/cloud-sync correctness.
