# Phase 2 changelog

## Added
- Personal dashboard
- Career Explorer
- Match Explorer
- Skill tracker
- Weekly review notes
- Daily action tracking
- Career Coach experience
- JSON backup and restore
- Expanded career-specific learning/project data
- Updated PWA cache and metadata

## Preserved
- Mobile-first responsive design
- 15-question assessment
- Rules-based career matching
- 90-day roadmap
- Report export / print
- Local-first privacy model

## Validation
- app.js passes Node syntax validation
- index.html references the new external app.js
- Phase 1 inline application code removed to prevent duplicate state/rendering

## Phase 2.1 hotfix
- Fixed assessment option rendering by restoring the missing character helper used by the option-button HTML.
- Verified the complete 15-question assessment flow in Chromium at desktop (1440×900) and mobile (390×844) viewports.
- Bumped the service-worker cache version so deployed phones do not retain the previous broken `app.js` cache.
