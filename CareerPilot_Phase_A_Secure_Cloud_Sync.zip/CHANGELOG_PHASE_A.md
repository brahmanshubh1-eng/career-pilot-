# Phase A changelog

- Hardened Supabase client sync flow and response checking.
- Added session refresh on startup and clearer recovery when a refresh token expires.
- Added forgot-password email request and recovery-link password update screen.
- Added pull-before-push sync to support restoring profile and daily progress on a new device.
- Stored assessment answers/results and user progress in the cloud profile JSON.
- Added owner-only delete RLS policies and user-requested cloud profile/log deletion.
- Added `updated_at` triggers and made CareerPilot policy setup re-runnable for its named policies.
- Kept billing entitlement server-controlled; no payment/paid-entitlement behavior was added.
