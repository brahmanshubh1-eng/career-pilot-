-- CareerPilot Phase A: secure account profile and progress sync.
-- Safe to re-run on an existing Supabase project.
create extension if not exists pgcrypto;

create table if not exists public.cp_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  name text not null default '',
  email text not null default '',
  career_id text,
  career_name text,
  career_score integer,
  assessment jsonb not null default '{}'::jsonb,
  plan90 jsonb not null default '{}'::jsonb,
  premium jsonb not null default '{"plan":"free"}'::jsonb,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table if not exists public.cp_daily_logs (
  user_id uuid not null references auth.users(id) on delete cascade,
  log_date date not null,
  day_number integer not null default 1,
  phase text not null default '',
  done integer not null default 0,
  score integer not null default 0,
  checkin integer,
  tasks jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, log_date)
);

create table if not exists public.cp_admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.cp_profiles enable row level security;
alter table public.cp_daily_logs enable row level security;
alter table public.cp_admin_users enable row level security;

create or replace function public.cp_is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.cp_admin_users where user_id = auth.uid()); $$;

-- Recreate only CareerPilot-owned policies so repeated setup doesn't fail.
drop policy if exists "profile owner read" on public.cp_profiles;
drop policy if exists "profile owner insert" on public.cp_profiles;
drop policy if exists "profile owner update" on public.cp_profiles;
drop policy if exists "daily owner read" on public.cp_daily_logs;
drop policy if exists "daily owner insert" on public.cp_daily_logs;
drop policy if exists "daily owner update" on public.cp_daily_logs;
drop policy if exists "profile owner delete" on public.cp_profiles;
drop policy if exists "daily owner delete" on public.cp_daily_logs;
drop policy if exists "admin self read" on public.cp_admin_users;

create policy "profile owner read" on public.cp_profiles for select to authenticated using (auth.uid() = user_id);
create policy "profile owner insert" on public.cp_profiles for insert to authenticated with check (auth.uid() = user_id);
create policy "profile owner update" on public.cp_profiles for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "profile owner delete" on public.cp_profiles for delete to authenticated using (auth.uid() = user_id);
create policy "daily owner read" on public.cp_daily_logs for select to authenticated using (auth.uid() = user_id);
create policy "daily owner insert" on public.cp_daily_logs for insert to authenticated with check (auth.uid() = user_id);
create policy "daily owner update" on public.cp_daily_logs for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "daily owner delete" on public.cp_daily_logs for delete to authenticated using (auth.uid() = user_id);
create policy "admin self read" on public.cp_admin_users for select to authenticated using (auth.uid() = user_id or public.cp_is_admin());

create or replace function public.cp_set_updated_at()
returns trigger language plpgsql set search_path = public
as $$ begin new.updated_at = now(); return new; end; $$;

drop trigger if exists cp_profiles_updated_at on public.cp_profiles;
create trigger cp_profiles_updated_at before update on public.cp_profiles for each row execute function public.cp_set_updated_at();
drop trigger if exists cp_daily_logs_updated_at on public.cp_daily_logs;
create trigger cp_daily_logs_updated_at before update on public.cp_daily_logs for each row execute function public.cp_set_updated_at();

-- Optional: make the first owner/admin after signing up. Never allow self-promotion from the browser.
-- insert into public.cp_admin_users(user_id) values ('YOUR_AUTH_USER_UUID');
