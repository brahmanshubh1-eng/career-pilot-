# Real AI Coach upgrade
- Replaced predefined Coach replies with calls to a server-side Vercel endpoint using the OpenAI Responses API.
- Added free-text questions and response/loading/error states.
- Sends career match, skills, goal, current phase, available time, daily tasks and check-in context for personalization.
- Keeps the OpenAI key server-side in environment variables.
- Added deployment setup instructions and honest configuration errors.
