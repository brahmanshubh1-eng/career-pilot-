# CareerPilot — Six Priorities After Launch

This launch-ready build is the baseline. Work through these in order, testing each stage before moving on.

1. **Authentication and secure cloud sync** — verify Supabase email flows, recovery, session refresh, row-level security (RLS), and sync across two devices.
2. **Database-backed user profiles and progress** — confirm schema and policies for assessment results, daily Coach tasks, roadmap progress, exports, and deletion. Users must only access their own rows.
3. **Secure AI Career Coach** — configure a server-side OpenAI API key only if budget allows; add rate limiting, usage limits, abuse protection, and clear offline fallback. Never put a secret key in browser files.
4. **Resume and job matching** — add resume upload/parse with consent, skill-gap comparison, job links, and transparent match reasons; do not promise hiring outcomes.
5. **Payments and subscriptions** — integrate checkout only after pricing is chosen; validate subscription status with signed server-side webhooks and enforce Premium access on the server. Do not treat a browser-only toggle as proof of payment.
6. **Analytics, onboarding, and launch QA** — collect minimal privacy-conscious events, improve onboarding from observed drop-offs, add error monitoring, accessibility checks, and test on real Android/iPhone/desktop browsers.

## Important launch boundaries
- The app works as a static web app and saves locally; cloud sync requires the configured Supabase project, valid schema, and correct RLS policies.
- Live AI responses require a configured server-side `OPENAI_API_KEY` and an account with API access/budget. Without it, the app must explain that live AI is unavailable and use its offline guidance where available.
- Payments are not connected in this build. Do not sell paid subscriptions until server-side payment verification is implemented and tested.
- Career matches are exploratory guidance, not validated aptitude results or guaranteed job/income outcomes.
