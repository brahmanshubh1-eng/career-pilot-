# CareerPilot Real AI Coach setup

The Premium Coach calls the server-side Vercel function `/api/coach`. The OpenAI secret is never included in browser JavaScript.

## Enable the AI
1. Deploy this project to Vercel with the `api/coach.js` file included.
2. Open **Vercel → Project → Settings → Environment Variables**.
3. Add `OPENAI_API_KEY` using your secret key from the OpenAI API platform. Never put it in `app.js` or `backend-config.json`.
4. Optional: add `OPENAI_MODEL` with value `gpt-4.1-mini` (the default).
5. Redeploy, open Premium Coach, and ask a question.

OpenAI API usage may cost money; configure usage limits/budget alerts. The Coach sends only relevant career profile fields and the question. Avoid sharing highly sensitive information.

**Production note:** the frontend Premium gate is not sufficient to prevent API abuse. Before a public paid launch, add server-side rate limiting and enforce Premium access against a verified Supabase session and billing entitlement.
