const careers=[
{id:"ai-automation",name:"AI Automation Specialist",category:"Technology + Business",interest:["technology","business"],strength:["problem","technology","organization"],env:["alone","team","business"],speed:3,earning:5,skills:["AI tools","Workflow automation","APIs","Problem solving"],learn:["Prompt design","Automation platforms","APIs & webhooks","Client workflow mapping"],project:"Automate a repetitive workflow for a real or simulated business."},
{id:"software",name:"Software Developer",category:"Technology",interest:["technology"],strength:["mathematics","problem","technology"],env:["alone","team"],speed:2,earning:5,skills:["Programming","Data structures","Git","Software projects"],learn:["Programming fundamentals","Git & GitHub","APIs","Testing"],project:"Build and publish a small useful web app."},
{id:"digital-marketing",name:"Digital Marketing Specialist",category:"Business + Marketing",interest:["marketing","business","content"],strength:["communication","creativity","writing","selling"],env:["team","people","business"],speed:4,earning:4,skills:["Content","SEO","Ads","Analytics"],learn:["Content strategy","SEO basics","Analytics","Campaign testing"],project:"Create a 30-day campaign for a mock or real brand."},
{id:"video",name:"Short-Form Video Creator",category:"Content + Creative",interest:["content","design"],strength:["creativity","writing"],env:["alone","business"],speed:5,earning:4,skills:["Editing","Storytelling","Hooks","AI video tools"],learn:["Hook writing","Editing workflow","Retention","Publishing"],project:"Produce 10 short videos around one focused niche."},
{id:"uiux",name:"UI/UX Designer",category:"Design + Technology",interest:["design","technology"],strength:["creativity","problem","organization"],env:["alone","team"],speed:3,earning:4,skills:["Figma","UX research","Wireframing","Prototyping"],learn:["UX research","Wireframing","Visual hierarchy","Prototyping"],project:"Redesign one real app flow and document the decisions."},
{id:"sales",name:"Sales & Business Development",category:"Business",interest:["business","marketing"],strength:["communication","selling","leadership"],env:["people","team","business"],speed:5,earning:5,skills:["Prospecting","Communication","Negotiation","CRM"],learn:["Prospecting","Discovery calls","Objection handling","CRM"],project:"Build a prospect list and write a complete outreach sequence."},
{id:"finance",name:"Finance & Analytics",category:"Finance + Data",interest:["finance","mathematics"],strength:["mathematics","research","organization","problem"],env:["alone","team"],speed:2,earning:5,skills:["Excel","Financial analysis","Data","Research"],learn:["Excel","Data cleaning","Financial statements","Dashboards"],project:"Create a simple financial analysis dashboard from public data."},
{id:"fitness",name:"Fitness & Wellness Creator",category:"Fitness + Content",interest:["fitness","content"],strength:["communication","creativity","organization"],env:["people","business"],speed:4,earning:3,skills:["Content","Coaching basics","Brand building","Community"],learn:["Content systems","Audience research","Community","Offer basics"],project:"Build a 30-day educational content series for a defined audience."}
];

const questions=[
{key:"status",q:"What are you currently doing?",opts:["School","College","Job","Freelancing","Business","Other"]},
{key:"hours",q:"How much time can you consistently invest each day?",opts:["<1 hour","1–2 hours","2–4 hours","4+ hours"]},
{key:"interest",q:"Which area interests you most?",opts:["Technology","Business","Finance","Design","Marketing","Content","Fitness"]},
{key:"strength",q:"What is one of your strongest abilities?",opts:["Communication","Creativity","Mathematics","Problem solving","Leadership","Writing","Selling","Technology","Organization","Research"]},
{key:"env",q:"Which working environment sounds best?",opts:["Working alone","Small team","Meeting lots of people","Running my own business"]},
{key:"income",q:"What monthly income goal matters most to you?",opts:["₹10k–25k","₹25k–50k","₹50k–1L","₹1L–3L","₹3L+"]},
{key:"speed",q:"How quickly do you want to start earning?",opts:["1–3 months","3–6 months","6–12 months","1–2 years","Long term"]},
{key:"learning",q:"How do you prefer to learn?",opts:["Build projects","Videos/courses","Reading","Working with a mentor"]},
{key:"risk",q:"Which path feels most comfortable?",opts:["Stable job","Freelance","Business","Either"]},
{key:"motivation",q:"What motivates you most?",opts:["High income","Freedom","Creativity","Security","Impact"]},
{key:"people",q:"How much people interaction do you want?",opts:["Low","Some","High"]},
{key:"tech",q:"How comfortable are you with technology?",opts:["Beginner","Comfortable","Advanced"]},
{key:"problem",q:"Which task sounds most enjoyable?",opts:["Solve a complex problem","Create something","Convince someone","Analyze information","Organize a system"]},
{key:"experience",q:"Do you already have a skill you could sell?",opts:["Yes","Not yet","I'm unsure"]},
{key:"commit",q:"Can you commit to one primary skill for 90 days?",opts:["Yes","Probably","No, I want to explore"]}
];

const STORE="careerpilot_phase5_v1";
const LEGACY_STORE="careerpilot_phase4_v1";
const DATA_VERSION=5;
function newId(){return (crypto?.randomUUID?.()||("cp_"+Date.now().toString(36)+Math.random().toString(36).slice(2,10))).toString()}
let state={version:DATA_VERSION,deviceId:"",updatedAt:"",screen:"home",i:0,answers:{},results:[],profile:{},saved:[],progress:{},checklist:{},skills:{},notes:"",daily:{},coachHistory:[],onboarded:false,account:{signedIn:false,name:"",email:"",userId:""},premium:{active:false,plan:"free",trialEnds:"",provider:"local",customerId:""},sync:{status:"local",lastSyncedAt:""},plan90:{startDate:"",startDay:1,completedDays:{},dailyLog:{},checkins:{},metrics:{applications:0,outreach:0,interviews:0,clients:0,revenue:0},weeklyReviews:{},incomeGoal:"",offer:""}};
function normalizeState(x){if(!x||typeof x!=="object")return state;const merged={...state,...x};merged.version=DATA_VERSION;merged.deviceId=merged.deviceId||newId();merged.account={...state.account,...(x.account||{})};merged.premium={...state.premium,...(x.premium||{})};merged.sync={...state.sync,...(x.sync||{})};merged.plan90={...state.plan90,...(x.plan90||{}),metrics:{...state.plan90.metrics,...((x.plan90||{}).metrics||{})},completedDays:{...((x.plan90||{}).completedDays||{})},dailyLog:{...((x.plan90||{}).dailyLog||{})},checkins:{...((x.plan90||{}).checkins||{})},weeklyReviews:{...((x.plan90||{}).weeklyReviews||{})}};return merged}
function load(){try{let raw=localStorage.getItem(STORE);if(!raw)raw=localStorage.getItem(LEGACY_STORE);const x=raw?JSON.parse(raw):null;if(x)state=normalizeState(x);if(!state.deviceId)state.deviceId=newId();}catch(e){state=normalizeState(state)}}
function save(){try{state.version=DATA_VERSION;state.deviceId=state.deviceId||newId();state.updatedAt=new Date().toISOString();localStorage.setItem(STORE,JSON.stringify(state))}catch(e){toast("Could not save changes on this device")}}

function chr(n){return String.fromCharCode(n)}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m]))}
function toast(t){const d=document.createElement("div");d.className="toast";d.textContent=t;document.body.appendChild(d);setTimeout(()=>d.remove(),1800)}
function pct(n,d){return d?Math.round(n/d*100):0}
function topCareer(){return state.results?.[0]}
function plan90Init(){
 if(!state.plan90||typeof state.plan90!=="object")state.plan90={};
 state.plan90.metrics={applications:0,outreach:0,interviews:0,clients:0,revenue:0,...(state.plan90.metrics||{})};
 state.plan90.completedDays=state.plan90.completedDays||{};
 state.plan90.dailyLog=state.plan90.dailyLog||{};
 state.plan90.checkins=state.plan90.checkins||{};
 state.plan90.weeklyReviews=state.plan90.weeklyReviews||{};
 if(!state.plan90.startDate)state.plan90.startDate=localDate();
 if(!state.plan90.startDay)state.plan90.startDay=1;
 save();
}
function day90(){
 plan90Init();
 const start=new Date(state.plan90.startDate+"T00:00:00"),now=new Date(localDate()+"T00:00:00");
 return Math.max(1,Math.min(90,Math.floor((now-start)/86400000)+Number(state.plan90.startDay||1)));
}
function phase90(d=day90()){
 if(d<=30)return {name:"Foundation",range:"Days 1–30",goal:"Build the skill and first proof of work"};
 if(d<=60)return {name:"Proof & Positioning",range:"Days 31–60",goal:"Build visible proof and position yourself for opportunities"};
 return {name:"Income Launch",range:"Days 61–90",goal:"Turn your skill into applications, clients, interviews or paid work"};
}
function week90(d=day90()){return Math.ceil(d/7)}
function incomeAction(c,d){
 if(d<=30)return `Build a sellable ${c.skills[0]} skill and one proof-of-work asset.`;
 if(d<=60)return `Package your ${c.name} skill into a clear offer and build a portfolio that proves the result.`;
 return `Create opportunities: targeted applications, client outreach, follow-ups and paid offers.`;
}

async function coachAsk(i){
 const prompts=["What should I do today?","How do I start earning in this career?","What skill should I improve next?","I feel stuck. Help me get moving."];
 await askAICoach(prompts[i]||prompts[0]);
}
function offlineCoachReply(question,c,d,p,tasks){
 const q=String(question||"").toLowerCase(),goal=state.profile?.careerGoal||state.plan90?.offer||`build skills for ${c.name}`,time=state.answers?.hours||"1–2 hours",done=dailyDoneCount();
 const first=tasks.find(t=>!t.done)||tasks[0];
 let focus,steps;
 if(/today|right now|next step|what should i do/.test(q)){
  focus=`Today's priority is ${first.title.toLowerCase()}.`;steps=[first.text,"Work in one focused 25-minute block, then take a short break.","Save the output or write down what you learned."];
 }else if(/earn|income|money|client|freelanc|job|salary/.test(q)){
  focus=`For ${c.name}, build proof before promising results. Your current phase is ${p.name}.`;steps=[`Create one small example that demonstrates ${c.skills[0]}.`,"Choose one specific employer, customer, or audience that needs this skill.",p.name==="Income Launch"?"Send one tailored application or outreach message and track the response.":"Ask one person for feedback and improve the example before pitching it."];
 }else if(/skill|learn|improv|study|beginner|start/.test(q)){
  const skill=c.skills.find(x=>q.includes(x.toLowerCase()))||c.skills[d%c.skills.length]||c.skills[0];
  focus=`Focus on one skill at a time: ${skill}.`;steps=[`Spend 20–30 minutes learning the basics of ${skill}.`,`Practice it in a tiny ${c.name} example rather than only watching tutorials.`,"Save your work and note one question to resolve tomorrow."];
 }else if(/stuck|motivat|procrastinat|overwhelm|confus|can't|cannot/.test(q)){
  focus="Reduce the task until it feels easy to start. You do not need to solve the whole career plan today.";steps=[`Set a 10-minute timer and begin: ${first.title}.`,"Ignore polish; make a rough first version.","When the timer ends, either stop without guilt or continue for another 10 minutes."];
 }else if(/plan|week|7.day|roadmap|90.day/.test(q)){
  focus=`Your current goal is “${goal}” and your 90-day phase is ${p.name}.`;steps=[`Days 1–2: practice ${c.skills[0]} and write down what you can now do.`,`Days 3–4: create a small project using ${c.skills[1]||c.skills[0]}.`,`Days 5–6: improve the project and ask for feedback.`,`Day 7: review what you finished and choose next week's one priority.`];
 }else{
  focus=`Based on your assessment, ${c.name} is your leading career direction (${c.score}% profile match). Treat this as a useful starting hypothesis, not a guarantee.`;steps=[`Build confidence in ${c.skills[0]} through a small practical exercise.`,`Create proof of work related to: ${c.project}`,`Review your goal (“${goal}”) and choose one measurable result for this week.`];
 }
 return `CareerPilot Coach • Free offline guidance\n\n${focus}\n\nYour available time: ${time}. Progress today: ${done}/4 tasks.\n\nYour next steps:\n${steps.map((x,i)=>`${i+1}. ${x}`).join("\n")}\n\nAfter you finish, record what you made and what blocked you. This offline Coach uses your saved profile and rules; it is not a live generative AI model. A live AI reply will work once the server endpoint and API billing are configured.`;
}
async function askAICoach(question){
 if(!premiumActive())return premiumPaywall(topCareer());
 ensureDaily();plan90Init();const c=topCareer();if(!c)return toast("Complete your career assessment first");
 const answer=document.getElementById("coachAnswer");if(answer)answer.textContent="Preparing personalized guidance…";
 const button=document.getElementById("coachSend");if(button){button.disabled=true;button.textContent="Working…";}
 const d=day90(),p=phase90(d),tasks=(state.daily?.tasks||[]).map(t=>({title:t.title,detail:t.text,done:!!t.done}));
 const payload={question:String(question||"").slice(0,1200),profile:{career:c.name,match:c.score,skills:c.skills,learning:c.learn,careerGoal:state.profile?.careerGoal||state.plan90?.offer||"",currentStatus:state.answers?.status||"Not specified",availableTime:state.answers?.hours||"Not specified",incomeGoal:state.answers?.income||state.plan90?.incomeGoal||"Not specified",learningStyle:state.answers?.learning||"Not specified",phase:p.name,day:d,tasks,completedToday:dailyDoneCount(),checkin:Number(state.plan90.checkins[localDate()]||0)}};
 let response="",mode="live";
 try{const headers={"Content-Type":"application/json"};if(typeof CP6!=="undefined"&&CP6.token)headers.Authorization=`Bearer ${CP6.token}`;const r=await fetch("/api/coach",{method:"POST",headers,body:JSON.stringify(payload)});const data=await r.json().catch(()=>({}));if(!r.ok)throw new Error(data.error||`AI Coach unavailable (${r.status})`);response=String(data.reply||"").trim();if(!response)throw new Error("The AI Coach returned an empty reply.");}
 catch(e){mode="offline";response=offlineCoachReply(question,c,d,p,tasks);}
 state.coachHistory=state.coachHistory||[];state.coachHistory.push(`You: ${question||"Coach guidance"}\n${mode==="live"?"AI Coach":"CareerPilot Coach (offline guidance)"}: ${response}`);state.coachHistory=state.coachHistory.slice(-8);save();
 const current=document.getElementById("coachAnswer");if(current)current.textContent=state.coachHistory[state.coachHistory.length-1];
 const b=document.getElementById("coachSend");if(b){b.disabled=false;b.textContent=mode==="live"?"Ask AI Coach →":"Ask Coach →";}
}
function setCoachGoal(){
 const c=topCareer(); const current=state.profile?.careerGoal||state.plan90.offer||c?.name||"";
 const v=prompt("What is your main career goal for the next 90 days?",current); if(v===null)return;
 state.profile=state.profile||{};state.profile.careerGoal=v.trim().slice(0,180);save();toast("Coach goal updated");render();
}
function go(s){state.screen=s;save();render()}
function premiumActive(){
 const p=state.premium||{};
 if(p.plan==="premium"&&p.active)return true;
 if(p.plan==="trial"){
  const valid=p.trialEnds&&new Date(p.trialEnds)>new Date();
  if(valid){if(!p.active){state.premium={...p,active:true};save()}return true}
  state.premium={active:false,plan:"free",trialEnds:""};save();return false;
 }
 return false;
}
function startTrial(){
 if(state.premium?.plan==="trial"&&state.premium?.trialEnds&&new Date(state.premium.trialEnds)>new Date())return go("premium");
 const end=new Date(Date.now()+3*86400000).toISOString();
 state.premium={active:true,plan:"trial",trialEnds:end};save();toast("3-day Premium trial started");go("premium");
}
function choosePlan(plan){
 if(plan==="free") {state.premium={active:false,plan:"free",trialEnds:""};save();toast("Free plan selected");go("home");return}
 startTrial();
}
function saveAccount(){
 const name=document.getElementById("accountName")?.value.trim()||"";
 const email=document.getElementById("accountEmail")?.value.trim()||"";
 if(name.length<2||!email||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return toast("Enter your name and a valid email");
 state.account={signedIn:true,name,email,userId:state.account?.userId||newId()};state.sync={status:"local",lastSyncedAt:""};save();toast("Profile created on this device");render();
}
function signOut(){state.account={signedIn:false,name:"",email:"",userId:""};state.sync={status:"local",lastSyncedAt:""};save();toast("Signed out on this device");render()}

function nav(active){
 const target=state.results.length?"dashboard":"assessment";
 return `<nav class="nav" aria-label="Primary navigation"><div class="nav-inner">
 <button class="${active==="home"?"active":""}" onclick="go('home')"><span class="navicon">⌂</span>Home</button>
 <button class="${active==="dashboard"||active==="assessment"?"active":""}" onclick="go('${target}')"><span class="navicon">◈</span>${state.results.length?"Dashboard":"Assess"}</button>
 <button class="${active==="roadmap"?"active":""}" onclick="go('roadmap')"><span class="navicon">◷</span>Plan</button>
 <button class="${active==="premium"||active==="coach"?"active":""}" onclick="go('premium')"><span class="navicon">✦</span>Premium</button>
 <button class="${active==="profile"?"active":""}" onclick="go('profile')"><span class="navicon">◉</span>Profile</button>
 </div></nav>`
}
function layout(content,active="home"){
 document.getElementById("app").innerHTML=`<main class="app page-in"><div class="topbar"><span class="brand">CareerPilot</span><button class="iconbtn" onclick="go('profile')">${state.results.length?"Profile":"About"}</button></div>${content}<p class="footer">CareerPilot • Career Guidance Coach</p></main>${nav(active)}`
}
function home(){
 const has=state.results.length,c=topCareer(),completed=Object.values(state.progress).filter(Boolean).length;
 layout(`<section class="hero"><div class="card">
 <span class="tag">CAREER DISCOVERY • PHASE 5</span>
 <h1>Find a direction.<br><em>Build your path.</em></h1>
 <p class="lead">CareerPilot connects your interests and strengths to career directions, then helps you turn one direction into skills, projects and next actions.</p>
 ${has?`<div class="mini-dashboard"><div><b>${esc(c.name)}</b><span class="small">${c.score}% profile match</span></div><div class="ring">${pct(completed,3)}%</div></div>`:""}
 <div class="row"><button class="btn" onclick="${has?"go('dashboard')":"start()"}">${has?"Open my dashboard":"Start career assessment"} →</button>${has?`<button class="btn secondary" onclick="start()">Retake assessment</button>`:""}</div>
 <p class="small">15 questions • ~3 minutes • Private by default • Saved on this device</p>
 </div></section>
 <div class="section grid3"><div class="card feature"><b>Discover</b><span>Career directions based on your answers.</span></div><div class="card feature"><b>Build</b><span>Skills and projects that create proof of work.</span></div><div class="card feature"><b>Act</b><span>Weekly actions so progress is measurable.</span></div></div>` ,"home");
 if(!state.onboarded && !has) setTimeout(showOnboarding,40);
}
function start(){if(state.results.length&& !confirm("Starting a new assessment will reset your current career match, roadmap progress, skills and daily plan. Continue?"))return;state.i=0;state.answers={};state.results=[];state.progress={};state.checklist={};state.skills={};state.daily={};state.coachHistory=[];state.plan90={startDate:"",startDay:1,completedDays:{},dailyLog:{},checkins:{},metrics:{applications:0,outreach:0,interviews:0,clients:0,revenue:0},weeklyReviews:{},incomeGoal:"",offer:""};state.screen="assessment";save();render()}
function assessment(){
 const q=questions[state.i],p=pct(state.i+1,questions.length);
 layout(`<div class="eyebrow">CAREER ASSESSMENT</div><div class="progress"><div class="bar" style="width:${p}%"></div></div>
 <div class="card"><div class="topline"><span class="small">Question ${state.i+1} of ${questions.length}</span><span class="small">${p}%</span></div>
 <h2 class="question">${esc(q.q)}</h2><div class="options">${q.opts.map(o=>`<button class="option ${state.answers[q.key]===o?"selected":""}" onclick='choose(${JSON.stringify(q.key).replace(chr(39),chr(38)+"#39;")},${JSON.stringify(o).replace(chr(39),chr(38)+"#39;")})'>${esc(o)}</button>`).join("")}</div>
 <div class="row actions"><button class="btn secondary" ${state.i===0?"disabled":""} onclick="prev()">← Back</button><button class="btn" ${state.answers[q.key]?"":"disabled"} onclick="nextQuestion()">${state.i===questions.length-1?"Finish assessment":"Next →"}</button></div></div>`,"assessment")
}
function choose(k,v){state.answers[k]=v;save();render()}
function prev(){if(state.i>0){state.i--;save();render()}}
function nextQuestion(){const q=questions[state.i];if(!state.answers[q.key])return toast("Please select an answer first");if(state.i<questions.length-1){state.i++;save();render()}else calc()}
function speedFit(v){return {"1–3 months":5,"3–6 months":4,"6–12 months":3,"1–2 years":2,"Long term":1}[v]||3}
function norm(v){return String(v||"").toLowerCase().replace(/[^a-z0-9]/g,"")}
function match(v,arr){const n=norm(v);return arr.some(x=>{const y=norm(x);return n===y||n.includes(y)||y.includes(n)})}
function calc(){
 const a=state.answers,envMap={"Working alone":"alone","Small team":"team","Meeting lots of people":"people","Running my own business":"business"};
 state.results=careers.map(c=>{
  let score=20,reasons=[];
  if(match(a.interest,c.interest)){score+=30;reasons.push(`Your main interest is ${a.interest}.`)}
  if(match(a.strength,c.strength)){score+=18;reasons.push(`It uses your strength in ${a.strength.toLowerCase()}.`)}
  if(match(a.env,c.env)||match(envMap[a.env],c.env)){score+=10;reasons.push("It matches your preferred work environment.")}
  if(Math.abs(c.speed-speedFit(a.speed))<=1){score+=8;reasons.push("It fits your preferred earning timeline.")}
  if(a.tech==="Advanced"&&c.interest.includes("technology")){score+=5;reasons.push("It benefits from your technology comfort.")}
  if(a.motivation==="High income"&&c.earning>=5){score+=4;reasons.push("It aligns with your stated income priority.")}
  if(a.risk==="Business"&&c.env.includes("business")){score+=3;reasons.push("It fits your preference for business-oriented work.")}
  return {...c,score:Math.min(98,score),reasons}
 }).sort((x,y)=>y.score-x.score);
 state.profile={answers:{...a}};state.progress={};state.checklist={};state.skills={};state.daily={};state.coachHistory=[];state.screen="dashboard";state.i=questions.length-1;state.onboarded=true;save();render()
}
function trialLabel(){
 if(!state.premium?.trialEnds||state.premium.plan!=="trial")return "";
 const ms=new Date(state.premium.trialEnds)-new Date();
 if(ms<=0)return "Trial ended";
 const h=Math.ceil(ms/3600000);
 return h<=24?`Trial ends in ${h}h`:`Trial ends in ${Math.ceil(h/24)} days`;
}
function primaryNextStep(c){
 const done=Object.values(state.progress).filter(Boolean).length;
 if(done===0)return `Start ${c.learn[0]} and finish one small practice session today.`;
 if(done===1)return `Build a small ${c.name} project using ${c.skills[0]}.`;
 if(done===2)return `Turn your best work into proof and begin targeted outreach.`;
 return `Keep your streak alive with one focused ${c.skills[0]} session today.`;
}
function dashboard(){
 if(!state.results.length){return layout(`<div class="card empty"><h2>Your dashboard starts with an assessment</h2><p class="muted">Answer 15 short questions to unlock your career match and personalized plan.</p><button class="btn" onclick="start()">Start assessment</button></div>`,"dashboard")}
 const c=topCareer(),done=Object.values(state.progress).filter(Boolean).length,skillDone=Object.values(state.skills).filter(Boolean).length;
 layout(`<div class="eyebrow">YOUR CAREER DASHBOARD</div>
 <section class="card dash-hero"><div><span class="tag">YOUR TOP MATCH</span><h2>${esc(c.name)}</h2><p class="muted">${esc(c.category)} • ${c.score}% profile overlap</p><p>${esc(c.reasons?.[0]||"This direction matched several of your assessment preferences.")}</p><div class="row"><button class="btn" onclick="careerDetail('${c.id}')">Why this fits →</button><button class="btn secondary" onclick="go('roadmap')">Start my plan</button></div></div><div class="big-ring" style="--score:${c.score}"><span>${c.score}%<small>match</small></span></div></section>
 <div class="statgrid four"><div class="stat"><b>${done}/3</b><span>Roadmap stages</span></div><div class="stat"><b>${skillDone}/${c.learn.length}</b><span>Skills tracked</span></div><div class="stat"><b>${c.score}%</b><span>Profile match</span></div><div class="stat"><b>${dailyDoneCount()}/4</b><span>Today's tasks</span></div></div>
 <div class="card section next-step"><div><div class="eyebrow">YOUR NEXT STEP</div><h3>${esc(primaryNextStep(c))}</h3><p class="small">Keep the goal small enough to complete today. Consistency matters more than doing everything at once.</p></div><button class="btn" onclick="go('premium')">Open Coach →</button></div>
 <div class="section"><div class="sectionhead"><h2>Today's coaching</h2><button class="textbtn" onclick="go('premium')">Open Premium</button></div><div class="card focus"><b>${esc(weeklyAction(c))}</b><p class="small">${dailyDoneCount()}/4 daily tasks complete • ${coachStreak()} day streak</p><button class="btn secondary" onclick="go('premium')">Open my daily plan →</button></div></div>
 <div class="section"><div class="sectionhead"><h2>Career matches</h2><button class="textbtn" onclick="go('matches')">See all</button></div>${state.results.slice(0,3).map((x,i)=>`<div class="result career" onclick="careerDetail('${x.id}')"><div><b>${esc(x.name)}</b><div class="small">${esc(x.category)}</div></div><span class="scorepill">${x.score}%</span></div>`).join("")}</div>
 <div class="section grid2"><div class="card feature clickable" onclick="go('skills')"><b>Skill tracker</b><span>Track the skills your chosen direction requires.</span></div><div class="card feature clickable" onclick="go('premium')"><b>Premium Coach</b><span>Daily tasks, personalized planning and coaching.</span></div></div>`,"dashboard")
}
function weeklyAction(c){const idx=Object.values(state.progress).filter(Boolean).length;if(idx===0)return `Start with ${c.learn[0]} and complete one focused practice session.`;if(idx===1)return `Build a small project using ${c.skills[0]} and document what you learned.`;return `Turn your strongest project into proof of work and start targeted outreach.`}
function localDate(){const d=new Date();return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10)}
function daysBetween(a,b){const x=new Date(a+"T00:00:00"),y=new Date(b+"T00:00:00");return Math.round((y-x)/86400000)}
function taskPlan(c){
 plan90Init();
 const d=day90(),p=phase90(d),a=state.profile?.answers||state.answers||{}, learner=a.learning||"Build projects";
 const learn=d<=30?(c.learn[(d-1)%c.learn.length]):c.learn[Math.min(2,c.learn.length-1)]||c.learn[0];
 const skill=c.skills[(d-1)%c.skills.length]||c.skills[0];
 let base=[
  {id:"learn",title:`Learn: ${learn}`,text:learner==="Videos/courses"?`Complete one focused lesson on ${learn} and write 3 takeaways.`:learner==="Reading"?`Study one focused resource on ${learn} and write 3 practical takeaways.`:`Spend 30–45 minutes practicing ${learn} and save what you learned.`},
  {id:"build",title:`Practice: ${skill}`,text:`Complete one small hands-on exercise using ${skill}. Save the output as evidence.`},
  {id:"proof",title:d<=30?"Build your proof of work":"Improve your portfolio proof",text:d<=30?`Create or improve one small ${c.name} project. Make the result visible.`:`Improve one portfolio item and make the result, process or outcome easy to understand.`},
  {id:"income",title:p.name==="Income Launch"?"Create an income opportunity":"Prepare for income",text:p.name==="Income Launch"?`Make one targeted application, outreach message, proposal, follow-up or paid offer today.`:`Identify one buyer/employer/client type who could value your ${skill}, and write down their problem.`}
 ];
 if(d%7===0)base[3]={id:"review",title:"Weekly review & reset",text:"Review your week, record results, choose one bottleneck and set next week's priority."};
 return base;
}
function ensureDaily(){
 if(!state.results.length)return;
 plan90Init();
 const today=localDate(),c=topCareer(),d=day90();
 if(state.daily?.date!==today){
   state.daily={date:today,day:d,phase:phase90(d).name,tasks:taskPlan(c).map(t=>({...t,done:false})),history:state.daily?.history||{}};
   save();
 }
 if(!Array.isArray(state.daily.tasks)||state.daily.tasks.length!==4){
   state.daily.tasks=taskPlan(c).map(t=>({...t,done:false}));
   save();
 }
}
function dailyDoneCount(){ensureDaily();return state.daily.tasks.filter(t=>t.done).length}
function dailyPct(){return pct(dailyDoneCount(),4)}
function historyDone(v){return typeof v==="number"?v:Number(v?.done||0)}
function coachStreak(){
 ensureDaily();
 const h=state.daily.history||{},today=localDate();let streak=0,cursor=today;
 if(historyDone(h[today])===0){const d=new Date(today+"T00:00:00");d.setDate(d.getDate()-1);cursor=d.toISOString().slice(0,10)}
 while(historyDone(h[cursor])>0){streak++;const d=new Date(cursor+"T00:00:00");d.setDate(d.getDate()-1);cursor=d.toISOString().slice(0,10);if(streak>365)break}
 return streak;
}
function markDayLog(){
 plan90Init();ensureDaily();
 const n=dailyDoneCount(),today=localDate(),check=state.plan90.checkins[today]||0;
 state.daily.history=state.daily.history||{};
 state.daily.history[today]={done:n,score:Math.round(n/4*100),checkin:check};
 state.plan90.dailyLog[today]={day:day90(),done:n,score:Math.round(n/4*100),checkin:check,phase:phase90().name};
 if(n===4)state.plan90.completedDays[today]=true;else delete state.plan90.completedDays[today];
 save();
}
function toggleDailyTask(i){
 ensureDaily();if(!state.daily.tasks[i])return;
 state.daily.tasks[i].done=!state.daily.tasks[i].done;markDayLog();
 toast(state.daily.tasks[i].done?"Task completed":"Task reopened");render();
}
function toggleDaily(){ensureDaily();state.daily.tasks.forEach(t=>t.done=true);markDayLog();toast("Today's plan completed");render()}
function setDailyCheckin(v){plan90Init();state.plan90.checkins[localDate()]=Number(v);markDayLog();toast("Daily check-in saved");render()}
function logMetric(kind){plan90Init();state.plan90.metrics[kind]=Number(state.plan90.metrics[kind]||0)+1;save();toast("Progress logged");render()}
function logRevenue(){
 plan90Init();const raw=prompt("Enter real revenue received today in ₹ (0 if none):");if(raw===null)return;
 const n=Number(String(raw).replace(/,/g,""));if(!Number.isFinite(n)||n<0)return toast("Enter a valid amount");
 state.plan90.metrics.revenue=Number(state.plan90.metrics.revenue||0)+n;save();toast("Revenue logged");render();
}
function setIncomeGoal(){
 plan90Init();const v=prompt("What is your 90-day income target in ₹?",state.plan90.incomeGoal||"50000");if(v===null)return;
 const n=Number(String(v).replace(/,/g,""));if(!Number.isFinite(n)||n<0)return toast("Enter a valid target");
 state.plan90.incomeGoal=n;save();render();
}
function setOffer(){
 plan90Init();const v=prompt("What service/job offer are you building?",state.plan90.offer||"");if(v===null)return;
 state.plan90.offer=v.trim().slice(0,180);save();render();
}
function careerDetail(id){const c=careers.find(x=>x.id===id)||topCareer();state.screen="career";state.saved=state.saved||[];state.savedCareer=id;save();render()}
function careerFitRows(c){
 const a=state.profile?.answers||state.answers||{}, envMap={"Working alone":"alone","Small team":"team","Meeting lots of people":"people","Running my own business":"business"};
 const rows=[
  {label:"Main interest",value:a.interest||"Not answered",ok:match(a.interest,c.interest)},
  {label:"Personal strength",value:a.strength||"Not answered",ok:match(a.strength,c.strength)},
  {label:"Work environment",value:a.env||"Not answered",ok:match(a.env,c.env)||match(envMap[a.env],c.env)},
  {label:"Earning timeline",value:a.speed||"Not answered",ok:Math.abs(c.speed-speedFit(a.speed))<=1},
  {label:"Technology comfort",value:a.tech||"Not answered",ok:a.tech==="Advanced"&&c.interest.includes("technology")},
  {label:"Income priority",value:a.motivation||"Not answered",ok:a.motivation==="High income"&&c.earning>=5},
  {label:"Business preference",value:a.risk||"Not answered",ok:a.risk==="Business"&&c.env.includes("business")}
 ];
 return rows;
}
function career(){
 const c=careers.find(x=>x.id===state.savedCareer)||topCareer();if(!c)return go("home");
 const fitRows=careerFitRows(c);
 const firstSteps=[`Explore ${c.learn[0]} with one beginner lesson or guide.`,`Practice ${c.skills[0]} for 25–30 minutes and save what you make.`,`Start this project: ${c.project}`];
 layout(`<div class="eyebrow">CAREER EXPLORER</div><div class="card"><span class="tag">${esc(c.category)}</span><h2>${esc(c.name)}</h2><p class="muted">CareerPilot compares your stated interests, strengths and preferences with this career direction. Use the result as a starting hypothesis—not a prediction of success or a job guarantee.</p><div class="statgrid"><div class="stat"><b>${c.score||"—"}%</b><span>Profile overlap</span></div><div class="stat"><b>${c.skills.length}</b><span>Core skills</span></div></div><p class="small">The percentage is a simple profile-overlap score, not a probability of getting hired or earning a particular income.</p></div>
 <div class="card section"><h3>Why this may fit you</h3><p class="muted">These are the assessment signals behind this match.</p>${fitRows.map(r=>`<div class="statusline"><span>${esc(r.label)}<small style="display:block;color:var(--muted)">${esc(r.value)}</small></span><b style="color:${r.ok?'#16845b':'#9a6700'}">${r.ok?'✓ Match':'Explore'}</b></div>`).join("")}</div>
 <div class="card section"><h3>Your first three steps</h3><ol style="padding-left:22px;line-height:1.65">${firstSteps.map(x=>`<li style="margin:8px 0">${esc(x)}</li>`).join("")}</ol><button class="btn" onclick="go('roadmap')">Use this in my roadmap →</button></div>
 <div class="card section"><h3>Core skills to build</h3><div>${c.skills.map(s=>`<span class="tag">${esc(s)}</span>`).join("")}</div></div>
 <div class="card section"><h3>Learning checklist</h3>${c.learn.map((s,i)=>`<label class="check"><input type="checkbox" ${state.skills[s]?"checked":""} onchange="toggleSkill(${JSON.stringify(s)})"><span>${esc(s)}</span></label>`).join("")}</div>` ,"dashboard")
}
function toggleSkill(s){state.skills[s]=!state.skills[s];save();toast(state.skills[s]?"Skill marked complete":"Skill reopened")}
function matches(){
 if(!state.results.length)return go("home");
 layout(`<div class="eyebrow">MATCH EXPLORER</div><div class="card"><h2>Directions that overlap with your profile</h2><p class="muted">Use these as exploration options. The percentages describe overlap with the assessment inputs, not future success.</p></div>${state.results.map((c,i)=>`<div class="result career clickable" onclick="careerDetail('${c.id}')"><div><b>${i+1}. ${esc(c.name)}</b><div class="small">${esc(c.reasons.slice(0,2).join(" "))}</div></div><span class="scorepill">${c.score}%</span></div>`).join("")}`,"dashboard")
}
function roadmap(){
 if(!state.results.length)return go("home");
 plan90Init();const c=topCareer(),d=day90(),p=phase90(d),complete=Object.keys(state.plan90.completedDays).length,weekly=Math.min(13,week90(d));
 const weeks=[...Array(13)].map((_,i)=>{const from=i*7+1,to=Math.min(90,(i+1)*7);let done=0;for(let x=from;x<=to;x++){const dt=new Date(state.plan90.startDate+"T00:00:00");dt.setDate(dt.getDate()+x-1);if(state.plan90.completedDays[dt.toISOString().slice(0,10)])done++}return {n:i+1,from,to,done}});
 const phaseCards=[
  {title:"Foundation",days:"1–30",text:`Master ${c.learn.slice(0,2).join(" + ")} and build your first proof-of-work asset.`,deliver:`First ${c.name} project + documented skill evidence`},
  {title:"Proof & Positioning",days:"31–60",text:`Build 2–3 strong examples around ${c.skills.slice(0,3).join(", ")} and package your value.`,deliver:"Portfolio + profile + clear offer/job target"},
  {title:"Income Launch",days:"61–90",text:"Run a consistent opportunity pipeline: applications, outreach, interviews, proposals, follow-ups and paid work.",deliver:"Measured opportunities and real revenue when earned"}
 ];
 layout(`<div class="eyebrow">PREMIUM • 90-DAY EXECUTION PLAN</div>
 <section class="card premium-hero"><div class="premium-badge">✦ DAY ${d} OF 90</div><h2>${esc(c.name)} — ${esc(p.name)}</h2><p class="muted">${esc(p.goal)}. Your plan changes with your day and your career stage.</p><div class="premium-context"><b>Today's mission</b><span>${esc(incomeAction(c,d))}</span></div></section>
 <div class="statgrid four section"><div class="stat"><b>${d}/90</b><span>Current day</span></div><div class="stat"><b>${complete}</b><span>Days completed</span></div><div class="stat"><b>${Math.round(complete/90*100)}%</b><span>90-day progress</span></div><div class="stat"><b>W${weekly}</b><span>Current week</span></div></div>
 ${phaseCards.map((m,i)=>`<div class="card roadmap-card"><div class="road-num">${i+1}</div><div><span class="tag">DAYS ${m.days}</span><h3>${m.title}</h3><p class="muted">${esc(m.text)}</p><p><b>Deliverable:</b> ${esc(m.deliver)}</p></div></div>`).join("")}
 <section class="card section"><div class="sectionhead"><div><h2>13-week execution map</h2><p class="small">Every week has a measurable output. Week ${weekly} is active.</p></div></div><div class="week-plan">${weeks.map(w=>`<div class="week-item ${w.n===weekly?"softdone":""}"><span>W${w.n}</span><div><b>Days ${w.from}–${w.to} ${w.n===weekly?"• NOW":""}</b><small>${w.done}/7 full days completed</small></div></div>`).join("")}</div></section>
 <section class="card section"><h3>Income target & offer</h3><p class="small">This tracks actual results; CareerPilot never guarantees income.</p><div class="statusline"><span>90-day target</span><b>${state.plan90.incomeGoal?`₹${Number(state.plan90.incomeGoal).toLocaleString("en-IN")}`:"Not set"}</b></div><div class="statusline"><span>Offer / target role</span><b>${esc(state.plan90.offer||"Not set")}</b></div><div class="row"><button class="btn secondary" onclick="setIncomeGoal()">Set income target</button><button class="btn secondary" onclick="setOffer()">Set offer/role</button></div></section>
 <div class="card section"><h3>Weekly review</h3><label class="check"><input type="checkbox" ${state.checklist.week?"checked":""} onchange="toggleCheck('week')"><span>I reviewed what I built this week.</span></label><label class="check"><input type="checkbox" ${state.checklist.next?"checked":""} onchange="toggleCheck('next')"><span>I chose one clear next action.</span></label><textarea class="notes" placeholder="Write one lesson, result or blocker..." oninput="state.notes=this.value;save()">${esc(state.notes)}</textarea></div>`,"roadmap")
}
function toggleProgress(i){state.progress[i]=!state.progress[i];save();toast(state.progress[i]?"Stage completed":"Stage reopened");render()}
function toggleCheck(k){state.checklist[k]=!state.checklist[k];save();render()}
function skills(){
 if(!state.results.length)return go("home");const c=topCareer(),total=c.learn.length,done=Object.values(state.skills).filter(Boolean).length;
 layout(`<div class="eyebrow">SKILL TRACKER</div><div class="card"><h2>Build the skill stack</h2><p class="muted">Track learning as evidence, not as a promise of mastery.</p><div class="big-progress"><span style="width:${pct(done,total)}%"></span></div><b>${done}/${total} skills marked complete</b></div><div class="card section">${c.learn.map(s=>`<label class="skill-row"><input type="checkbox" ${state.skills[s]?"checked":""} onchange="toggleSkill('${esc(s)}')"><span><b>${esc(s)}</b><small>${state.skills[s]?"Completed":"Not completed yet"}</small></span></label>`).join("")}</div><div class="card"><h3>Practice rule</h3><p class="muted">For each skill, create something you can show: a project, case study, workflow, analysis or documented result.</p></div>`,"dashboard")
}
function premiumPaywall(c){
 layout(`<section class="card premium-hero"><div class="premium-badge">✦ CAREERPILOT PREMIUM</div><h2>Your career plan, coached every day.</h2><p class="muted">Unlock the personalized daily Coach, 7-day action plan, daily missions and coaching prompts built around your ${esc(c.name)} direction.</p><div class="premium-context"><b>${esc(c.name)}</b><span>${c.score}% profile match • Personalized from your assessment</span></div></section>
 <section class="card section"><div class="eyebrow">PREMIUM COACH</div><h2>Everything you need to stay consistent</h2><div class="premium-features"><div><b>✓ Daily tasks</b><span>3 focused actions every day.</span></div><div><b>✓ Personalized plan</b><span>A focused 7-day plan built around your career direction.</span></div><div><b>✓ Daily Coach guidance</b><span>Practical next steps adapted to your career direction and learning style.</span></div><div><b>✓ Coach guidance</b><span>Practical answers based on your career goal, skills and today’s mission.</span></div></div></section>
 <section class="card section pricing-card"><div class="price-label">PREMIUM COACH</div><h2>Start free, then upgrade when it helps.</h2><p class="muted">Try the complete coaching workflow for 3 days. Production billing can be connected without changing the customer experience.</p><div class="price">₹0 <span>3-day trial</span></div><button class="btn" onclick="startTrial()">Start my free trial →</button><p class="small center">No payment is collected in this prototype.</p></section>
 <section class="card section"><h3>Want to keep it free?</h3><p class="muted">You can continue using your assessment, career matches and roadmap without Premium.</p><button class="btn secondary" onclick="choosePlan('free')">Continue with Free</button></section>`,"premium");
}

function coach(){
 if(!state.results.length)return go("home");
 if(!premiumActive())return premiumPaywall(topCareer());
 ensureDaily();plan90Init();
 const c=topCareer(),tasks=state.daily.tasks,d=day90(),p=phase90(d);
 const sevenDayPlan=Array.from({length:7},(_,i)=>{
   const futureDay=Math.min(90,d+i), phase=phase90(futureDay);
   const skill=c.skills[(futureDay-1)%c.skills.length]||c.skills[0];
   const learn=c.learn[(futureDay-1)%c.learn.length]||c.learn[0];
   return {day:futureDay,phase:phase.name,focus:i===0?"Today's mission":(i===1?`Practice ${skill}`:i===2?`Learn ${learn}`:i===3?`Build proof for ${c.name}`:i===4?"Improve your portfolio or project":i===5?"Create one opportunity":"Review the week and choose the next priority")};
 });
 const suggestions=[
  `What should I do today? → ${incomeAction(c,d)}`,
  `How do I start earning? → Build proof, choose one buyer/employer type, then consistently apply or outreach and improve from real responses.`,
  `What should I improve? → Focus on ${c.skills[Math.min(1,c.skills.length-1)]||c.skills[0]} and turn it into visible proof.`,
  `I feel stuck → Complete the first task for 30 minutes, save the output, then ask your Coach what to do next.`
 ];
 layout(`<div class="eyebrow">PREMIUM • CAREER COACH</div>
 <section class="card premium-hero"><div class="premium-badge">✦ PERSONALIZED COACH</div><h2>Your career plan, one day at a time.</h2><p class="muted">Your Coach turns your assessment into a practical plan for ${esc(c.name)} — with one clear mission today and a focused 7-day path.</p><div class="premium-context"><b>${esc(c.name)}</b><span>${c.score}% profile match • ${esc(p.name)}</span></div></section>
 <div class="premium-active-pill">${state.premium.plan==="trial"?`Premium trial active • ${trialLabel()}`:"Premium active"}</div>
 <section class="card section"><div class="sectionhead"><div><div class="eyebrow">YOUR 90-DAY GOAL</div><h3>${esc(state.profile?.careerGoal||"Set one clear outcome")}</h3><p class="small">Your Coach uses this goal to keep your daily actions focused.</p></div><button class="textbtn" onclick="setCoachGoal()">${state.profile?.careerGoal?"Edit":"Set goal"}</button></div></section>
 <section class="card section"><div class="sectionhead"><div><h2>Today's mission</h2><p class="small">Your most important action for today.</p></div></div><div class="premium-context"><b>${esc(incomeAction(c,d))}</b><span>Built for your current ${esc(p.name)} phase.</span></div></section>
 <section class="card section"><div class="sectionhead"><div><h2>Today's 4 actions</h2><p class="small">Four focused actions chosen for your career direction.</p></div></div><div class="daily-tasks">${tasks.map((t,i)=>`<label class="daily-task ${t.done?"done":""}"><input type="checkbox" ${t.done?"checked":""} onchange="toggleDailyTask(${i})"><span><b>${esc(t.title)}</b><small>${esc(t.text)}</small></span><em>${t.done?"Done":"Task"}</em></label>`).join("")}</div></section>
 <section class="card section"><h2>Your personalized 7-day plan</h2><p class="small">A simple sequence to keep you moving without overwhelm.</p><div class="daily-tasks">${sevenDayPlan.map((x,i)=>`<div class="daily-task"><span><b>Day ${i+1} • ${esc(x.focus)}</b><small>${esc(x.phase)} • Career focus: ${esc(c.name)}</small></span><em>${i===0?"Today":"Next"}</em></div>`).join("")}</div></section>
 <section class="card section"><h2>Daily check-in</h2><p class="small">Use this privately to reflect on how focused you felt today.</p><div class="checkin-row">${[1,2,3,4,5].map(v=>`<button class="checkin ${Number(state.plan90.checkins[localDate()])===v?"selected":""}" onclick="setDailyCheckin(${v})">${v}</button>`).join("")}</div></section>
 <section class="card section"><h3>Ask your Coach</h3><div class="coach-actions">${suggestions.map((s,i)=>`<button class="coach-q" onclick="coachAsk(${i})">${esc(s.split(" → ")[0])}<span>→</span></button>`).join("")}</div></section>
 <section class="card section"><h3>Talk to your Career Coach</h3><p class="small">Ask about your career, skills, daily plan, portfolio or job/client search. CareerPilot uses live AI only when the server and API account are configured; otherwise it gives built-in offline guidance.</p><textarea id="coachQuestion" class="field" rows="3" placeholder="Example: I have 45 minutes today and I am a beginner. What exactly should I do?"></textarea><button class="btn" id="coachSend" onclick="askAICoach(document.getElementById('coachQuestion')?.value?.trim()||'Give me my most important next step today.')">Ask Career Coach →</button><h3 style="margin-top:18px">Coach response</h3><div class="coach-answer" id="coachAnswer" aria-live="polite">${state.coachHistory.length?esc(state.coachHistory[state.coachHistory.length-1]):"Your AI Coach will use your career profile, goal and today's tasks to give specific guidance."}</div></section>
 <p class="small premium-note">Your Premium Coach is designed for the client's own use. CareerPilot does not display a client-progress dashboard in the app.</p>`,"premium")
}
function profile(){
 const c=topCareer(),done=Object.values(state.progress).filter(Boolean).length;
 const premium=premiumActive(),acct=state.account||{};
 const accountBlock=acct.signedIn
  ? '<p class="muted">'+esc(acct.email)+'</p><div class="statusline"><span>Account ID</span><b class="mono">'+esc(acct.userId||state.deviceId.slice(0,12))+'</b></div><div class="statusline"><span>Data status</span><b>'+((state.sync?.status==="synced")?"Synced":"On this device")+'</b></div><button class="btn secondary" onclick="signOut()">Sign out</button>'
  : '<p class="muted">Create a local profile now. This prepares your account identity for secure cloud sync without pretending that a real server account exists yet.</p><div class="form-grid"><input id="accountName" class="field" placeholder="Your name" autocomplete="name"><input id="accountEmail" class="field" type="email" placeholder="Email address" autocomplete="email"></div><button class="btn" onclick="saveAccount()">Create profile →</button>';
 const careerBlock=c
  ? '<div class="mini-dashboard"><div><b>'+esc(c.name)+'</b><span class="small">Primary direction</span></div><div class="ring">'+c.score+'%</div></div>'
  : '<p class="muted">No assessment completed yet.</p>';
 const premiumStatus=premium?(state.premium.plan==="trial"?"Trial • "+trialLabel():"Premium"):"Free";
 const premiumButton=premium?'':'<button class="btn" onclick="go(\'premium\')">View Premium →</button>';
 layout('<div class="card account-card"><div class="eyebrow">ACCOUNT</div><h2>'+(acct.signedIn?'Welcome, '+esc(acct.name):'Create your CareerPilot profile')+'</h2>'+accountBlock+'</div>'+
 '<div class="card"><div class="eyebrow">YOUR PROFILE</div><h2>CareerPilot settings</h2>'+careerBlock+
 '<div class="statgrid"><div class="stat"><b>'+(state.results.length?'1':'0')+'</b><span>Assessment</span></div><div class="stat"><b>'+done+'/3</b><span>Roadmap stages</span></div><div class="stat"><b>'+premiumStatus+'</b><span>Plan</span></div></div></div>'+
 '<div class="card section"><h3>Data & privacy</h3><p class="muted">CareerPilot currently stores your assessment, progress and profile on this device. Nothing here claims to be a secure cloud account yet.</p><div class="row"><button class="btn secondary" onclick="exportData()">Export my data</button><button class="btn secondary" onclick="triggerImport()">Restore backup</button></div><input id="importFile" type="file" accept=".json,application/json" class="hide" onchange="importData(event)"></div>'+
 '<div class="card section"><h3>Premium status</h3><div class="statusline"><span>Current plan</span><b>'+premiumStatus+'</b></div><div class="statusline"><span>Payments</span><b>Not connected</b></div><p class="small">The Premium experience is ready for a real billing provider. Never enter payment details into this prototype.</p>'+premiumButton+'</div>'+
 '<div class="card section"><h3>Production readiness</h3><div class="statusline"><span>Assessment engine</span><b>Live</b></div><div class="statusline"><span>Career matching</span><b>Live</b></div><div class="statusline"><span>Roadmap & tracking</span><b>Live</b></div><div class="statusline"><span>Premium Coach</span><b>Live</b></div><div class="statusline"><span>Cloud authentication</span><b>Ready for backend</b></div><div class="statusline"><span>Payments</span><b>Ready for provider</b></div></div>'+
 '<div class="card section"><h3>Reset & delete</h3><p class="small">Delete all CareerPilot data stored on this device. This cannot delete a future cloud account until cloud infrastructure is connected.</p><button class="btn dangerbtn" onclick="resetData()">Delete local data</button></div>','profile');
}
let onboardingStep=0;
function showOnboarding(){
 if(state.onboarded||state.results.length)return;
 const slides=[
  {icon:"✦",title:"Welcome to CareerPilot",text:"A simple mobile-first career companion that turns your interests into a direction and an action plan."},
  {icon:"◎",title:"Discover your direction",text:"Answer 15 focused questions. CareerPilot compares your interests, strengths and preferences across career paths."},
  {icon:"→",title:"Turn it into action",text:"Track skills, complete a 90-day roadmap and use the Career Coach to keep moving one step at a time."}
 ];
 const s=slides[onboardingStep];
 const dots=slides.map((_,i)=>`<i class="${i===onboardingStep?'active':''}"></i>`).join('');
 const last=onboardingStep===slides.length-1;
 const d=document.createElement('div');d.className='onboarding-backdrop';d.id='onboarding';d.innerHTML=`<section class="onboarding-sheet" role="dialog" aria-modal="true"><div class="onboarding-icon">${s.icon}</div><div class="eyebrow">CAREERPILOT</div><h2>${s.title}</h2><p class="lead">${s.text}</p><div class="onboarding-dots">${dots}</div><button class="btn" onclick="onboardingNext()">${last?'Get started':'Continue'} →</button>${!last?'<button class="btn secondary" style="margin-top:8px" onclick="finishOnboarding()">Skip intro</button>':''}</section>`;document.body.appendChild(d);
}
function onboardingNext(){if(onboardingStep<2){onboardingStep++;showOnboarding();document.getElementById('onboarding')?.remove()}else finishOnboarding()}
function finishOnboarding(){state.onboarded=true;save();document.getElementById('onboarding')?.remove()}
let deferredInstallPrompt=null;
function setupInstallPrompt(){
 window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstallPrompt=e;const b=document.getElementById('installBanner');if(b&&!localStorage.getItem('careerpilot_install_dismissed'))b.classList.add('show')});
 document.getElementById('installBtn')?.addEventListener('click',async()=>{if(!deferredInstallPrompt){toast('Use your browser menu → Add to Home screen');return}deferredInstallPrompt.prompt();try{await deferredInstallPrompt.userChoice}catch(e){}deferredInstallPrompt=null;document.getElementById('installBanner')?.classList.remove('show')});
 document.getElementById('installClose')?.addEventListener('click',()=>{localStorage.setItem('careerpilot_install_dismissed','1');document.getElementById('installBanner')?.classList.remove('show')});
}
function mobileAppInit(){document.body.classList.add('app-mode');setupInstallPrompt();}
function reportText(){
 const c=topCareer();if(!c)return "Complete the CareerPilot assessment first.";
 return ["CAREERPILOT PERSONAL CAREER REPORT","","Primary direction: "+c.name,"Profile match: "+c.score+"%","","Why it may fit:",...c.reasons.map(x=>"• "+x),"","Core skills:",...c.skills.map(x=>"• "+x),"","Learning focus:",...c.learn.map(x=>"• "+x),"","90-day roadmap:","• Days 1–30: Build foundations and complete a practice project.","• Days 31–60: Build 2–3 proof-of-work projects.","• Days 61–90: Target applications, outreach, internships or clients.","","CareerPilot provides guidance for exploration, not guaranteed outcomes."].join("\n")
}
function exportReport(){if(!state.results.length)return toast("Complete the assessment first");const a=document.createElement("a"),blob=new Blob([reportText()],{type:"text/plain;charset=utf-8"});a.href=URL.createObjectURL(blob);a.download="CareerPilot-Career-Report.txt";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1000);toast("Report exported")}
function exportData(){const backup={...state,exportedAt:new Date().toISOString(),exportFormat:"careerpilot-v5"};const blob=new Blob([JSON.stringify(backup,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="CareerPilot-backup.json";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1000);toast("Backup downloaded")}
function triggerImport(){document.getElementById("importFile").click()}
function importData(e){const f=e.target.files?.[0];if(!f)return;if(f.size>2*1024*1024)return toast("Backup file is too large");const r=new FileReader();r.onload=()=>{try{const x=JSON.parse(r.result);if(!x||typeof x!=="object"||!x.version)throw Error();if(!confirm("Restore this backup and replace your current CareerPilot data?"))return;const keepDevice=state.deviceId;state=normalizeState(x);state.deviceId=keepDevice;state.sync={status:"local",lastSyncedAt:""};save();toast("Backup restored");render()}catch(err){toast("Invalid CareerPilot backup")}};r.readAsText(f)}
function printReport(){if(!state.results.length)return toast("Complete the assessment first");const w=window.open("","_blank");if(!w)return toast("Allow pop-ups to print");w.document.write(`<!doctype html><title>CareerPilot Report</title><style>body{font-family:system-ui;max-width:760px;margin:40px auto;padding:20px;line-height:1.6}pre{white-space:pre-wrap;font:inherit}</style><h1>CareerPilot Career Report</h1><pre>${esc(reportText())}</pre><script>window.onload=()=>window.print()<\/script>`);w.document.close()}
async function shareResult(){if(!state.results.length)return toast("Complete the assessment first");const c=topCareer(),data={title:"My CareerPilot result",text:`My CareerPilot direction is ${c.name} (${c.score}% profile match).`};try{if(navigator.share)await navigator.share(data);else{await navigator.clipboard.writeText(data.text);toast("Result copied")}}catch(e){}}
function resetData(){if(confirm("Reset all CareerPilot data on this device?")){localStorage.removeItem(STORE);location.reload()}}
function render(){load();const routes={home,assessment,dashboard,roadmap,coach,premium:coach,profile,career,matches,skills};(routes[state.screen]||home)()}


/* ==================== PHASE 6: REAL SAAS LAYER ==================== */
let CP6={config:{auth:{provider:"supabase",url:"",anonKey:""},api:{baseUrl:""},payments:{provider:"razorpay",publishableKey:"",checkoutEndpoint:"/api/create-checkout-session",webhookEndpoint:"/api/billing/webhook"},admin:{enabled:false}},cloud:false,token:"",refreshToken:"",syncTimer:null,admin:false};
function cp6Ready(){return !!(CP6.config.auth?.url&&CP6.config.auth?.anonKey)}
function cp6ApiBase(){return (CP6.config.api?.baseUrl||"").replace(/\/$/,"")}
async function cp6LoadConfig(){
 try{const r=await fetch("./backend-config.json",{cache:"no-store"});if(r.ok)CP6.config={...CP6.config,...await r.json()}}catch(e){}
 try{const s=JSON.parse(localStorage.getItem("careerpilot_phase6_session")||"null");if(s?.accessToken){CP6.token=s.accessToken;CP6.refreshToken=s.refreshToken||""}}catch(e){}
 // Supabase password recovery returns a short-lived recovery access token in the URL fragment.
 try{const h=new URLSearchParams((location.hash||"").replace(/^#/,""));if(h.get("type")==="recovery"&&h.get("access_token")){CP6.token=h.get("access_token");CP6.refreshToken=h.get("refresh_token")||"";state.phase6={...(state.phase6||{}),recoveryMode:true};state.account={...(state.account||{}),signedIn:true};}}
 catch(e){}
 state.phase6=state.phase6||{cloudEnabled:cp6Ready(),lastCloudError:"",lastCloudSync:"",events:[],serverPremium:false};
}
function cp6Headers(){return {"apikey":CP6.config.auth.anonKey,"Authorization":`Bearer ${CP6.token||CP6.config.auth.anonKey}`,"Content-Type":"application/json"}}
async function cp6RefreshEntitlement(){
 // Paid access is deliberately NOT granted from browser-editable profile JSON.
 // A verified billing webhook/server endpoint must be added before paid Premium is enabled.
 if(state.premium?.source==="server")state.premium={active:false,plan:"free",trialEnds:"",source:"local"};
 return false;
}
async function cp6RefreshSession(){
 if(!cp6Ready()||!CP6.refreshToken)return false;
 const r=await fetch(`${CP6.config.auth.url}/auth/v1/token?grant_type=refresh_token`,{method:"POST",headers:{"apikey":CP6.config.auth.anonKey,"Content-Type":"application/json"},body:JSON.stringify({refresh_token:CP6.refreshToken})});
 const j=await r.json().catch(()=>({}));
 if(!r.ok)throw Error(j.msg||j.message||j.error_description||"Your session expired. Please sign in again.");
 CP6.token=j.access_token;CP6.refreshToken=j.refresh_token||CP6.refreshToken;
 localStorage.setItem("careerpilot_phase6_session",JSON.stringify({accessToken:CP6.token,refreshToken:CP6.refreshToken}));
 if(j.user){state.account={...(state.account||{}),signedIn:true,userId:j.user.id,email:j.user.email||state.account?.email||"",name:j.user.user_metadata?.name||state.account?.name||j.user.email?.split("@")[0]||""}}
 return true;
}
async function cp6Request(path,options={}){
 const r=await fetch(`${CP6.config.auth.url}${path}`,{...options,headers:{...cp6Headers(),...(options.headers||{})}});
 const raw=await r.text();let data={};try{data=raw?JSON.parse(raw):{}}catch(e){data={message:raw}}
 if(!r.ok)throw Error(data.msg||data.message||data.error_description||`Cloud request failed (${r.status})`);
 return data;
}
function cp6ApplyCloudProfile(row,logs=[]){
 const a=row?.assessment||{};
 if(a&&typeof a==="object"){
  if(a.answers)state.answers=a.answers;
  if(Array.isArray(a.results))state.results=a.results;
  if(a.profile)state.profile={...(state.profile||{}),...a.profile};
  for(const k of ["saved","progress","skills","checklist","notes","daily","coachHistory"])if(a[k]!==undefined)state[k]=a[k];
 }
 if(row?.plan90&&typeof row.plan90==="object")state.plan90={...(state.plan90||{}),...row.plan90,metrics:{...(state.plan90?.metrics||{}),...(row.plan90.metrics||{})},completedDays:{...(row.plan90.completedDays||{})},dailyLog:{...(state.plan90?.dailyLog||{}),...(row.plan90.dailyLog||{})},checkins:{...(state.plan90?.checkins||{}),...(row.plan90.checkins||{})},weeklyReviews:{...(state.plan90?.weeklyReviews||{}),...(row.plan90.weeklyReviews||{})}};
 for(const log of logs){state.plan90.dailyLog=state.plan90.dailyLog||{};state.plan90.dailyLog[log.log_date]={day:log.day_number,phase:log.phase,done:log.done,score:log.score,checkin:log.checkin,tasks:log.tasks||[]};if(log.done>=4)state.plan90.completedDays[log.day_number]=true;if(log.checkin!=null)state.plan90.checkins[log.log_date]=log.checkin;if(log.log_date===localDate()&&Array.isArray(log.tasks))state.daily={...(state.daily||{}),tasks:log.tasks};}
 state.account={...(state.account||{}),signedIn:true,userId:row.user_id,name:row.name||state.account?.name||"",email:row.email||state.account?.email||""};
 state.updatedAt=row.updated_at||state.updatedAt;state.sync={status:"synced",lastSyncedAt:new Date().toISOString()};
}
async function cp6Auth(mode){
 if(!cp6Ready())return toast("Cloud account is not configured yet. Add Supabase details to backend-config.json.");
 const localDataTimestamp=state.updatedAt||"";
 const email=(document.getElementById("authEmail")?.value||"").trim(),password=document.getElementById("authPassword")?.value||"",name=(document.getElementById("authName")?.value||"").trim();
 if(!email||password.length<6||(mode==="signup"&&name.length<2))return toast(mode==="signup"?"Enter name, email and a 6+ character password":"Enter email and a 6+ character password");
 const endpoint=mode==="signup"?`${CP6.config.auth.url}/auth/v1/signup`:`${CP6.config.auth.url}/auth/v1/token?grant_type=password`;
 const body=mode==="signup"?{email,password,data:{name}}:{email,password};
 try{
  const r=await fetch(endpoint,{method:"POST",headers:{"apikey":CP6.config.auth.anonKey,"Content-Type":"application/json"},body:JSON.stringify(body)}),j=await r.json();
  if(!r.ok)throw Error(j.msg||j.message||j.error_description||"Authentication failed");
  if(mode==="signup"&&!j.access_token){toast("Account created. Check your email to confirm, then sign in.");return}
  CP6.token=j.access_token;CP6.refreshToken=j.refresh_token||"";localStorage.setItem("careerpilot_phase6_session",JSON.stringify({accessToken:CP6.token,refreshToken:CP6.refreshToken}));
  state.account={signedIn:true,name:name||j.user?.user_metadata?.name||j.user?.email?.split("@")[0]||"",email:j.user?.email||email,userId:j.user?.id||state.account.userId||newId()};
  state.phase6={...(state.phase6||{}),cloudEnabled:true,lastCloudError:"",syncCompareLocalUpdatedAt:localDataTimestamp};state.sync={status:"cloud",lastSyncedAt:""};save();await cp6RefreshEntitlement();await cp6Sync(true);toast("Cloud account connected");render();
 }catch(e){state.phase6={...(state.phase6||{}),lastCloudError:e.message||"Authentication failed"};save();toast(e.message||"Authentication failed")}
}
async function cp6SignOut(){
 try{if(CP6.token&&cp6Ready())await fetch(`${CP6.config.auth.url}/auth/v1/logout`,{method:"POST",headers:{"apikey":CP6.config.auth.anonKey,"Authorization":`Bearer ${CP6.token}`}})}catch(e){}
 CP6.token="";CP6.refreshToken="";localStorage.removeItem("careerpilot_phase6_session");state.account={signedIn:false,name:"",email:"",userId:""};state.sync={status:"local",lastSyncedAt:""};save();toast("Signed out");render()
}
function cp6Payload(){
 const c=topCareer();return {user_id:state.account.userId,name:state.account.name||"",email:state.account.email||"",career_id:c?.id||null,career_name:c?.name||null,career_score:c?.score||null,assessment:{answers:state.answers||{},results:state.results||[],profile:state.profile||{},saved:state.saved||[],progress:state.progress||{},skills:state.skills||{},checklist:state.checklist||{},notes:state.notes||"",daily:state.daily||{},coachHistory:(state.coachHistory||[]).slice(-8)},plan90:state.plan90||{},premium:{plan:"free"},updated_at:new Date().toISOString()}
}
async function cp6Sync(force=false){
 if(!cp6Ready()||!CP6.token||!state.account?.userId)return false;
 clearTimeout(CP6.syncTimer);
 try{
  const uid=encodeURIComponent(state.account.userId);
  const rows=await cp6Request(`/rest/v1/cp_profiles?select=*&user_id=eq.${uid}&limit=1`);
  const cloud=rows?.[0]||null;
  const logs=await cp6Request(`/rest/v1/cp_daily_logs?select=*&user_id=eq.${uid}&order=log_date.asc`);
  const localHasData=!!(state.results?.length||Object.keys(state.answers||{}).length||Object.keys(state.plan90?.dailyLog||{}).length);
  const cloudHasData=!!(cloud&&(cloud.assessment&&Object.keys(cloud.assessment).length||cloud.plan90&&Object.keys(cloud.plan90).length));
  const localTime=Date.parse(state.phase6?.syncCompareLocalUpdatedAt||state.updatedAt||0)||0,cloudTime=Date.parse(cloud?.updated_at||0)||0;
  if(cloud&&cloudHasData&&(!localHasData||cloudTime>localTime)){
   cp6ApplyCloudProfile(cloud,logs||[]);save();
  }else{
   // Merge remote daily history even when this device's profile is newer.
   if(cloud)cp6ApplyCloudProfile({...cloud,assessment:{},plan90:{}},logs||[]);
   const payload=cp6Payload();
   await cp6Request(`/rest/v1/cp_profiles?on_conflict=user_id`,{method:"POST",headers:{Prefer:"resolution=merge-duplicates,return=minimal"},body:JSON.stringify(payload)});
   const localLogs=Object.entries(state.plan90?.dailyLog||{}).slice(-90).map(([date,v])=>({user_id:state.account.userId,log_date:date,day_number:Number(v.day||1),phase:v.phase||"",done:Number(v.done||0),score:Number(v.score||0),checkin:v.checkin!=null?Number(v.checkin):null,tasks:Array.isArray(v.tasks)?v.tasks:(date===localDate()?(state.daily?.tasks||[]):[])}));
   if(localLogs.length)await cp6Request(`/rest/v1/cp_daily_logs?on_conflict=user_id,log_date`,{method:"POST",headers:{Prefer:"resolution=merge-duplicates,return=minimal"},body:JSON.stringify(localLogs)});
   // Re-pull after upload so the UI reflects server-confirmed sync status.
   const verified=await cp6Request(`/rest/v1/cp_profiles?select=user_id,updated_at&user_id=eq.${uid}&limit=1`);
   if(!verified?.length)throw Error("Cloud sync could not be verified. Your local copy is safe.");
  }
  state.sync={status:"synced",lastSyncedAt:new Date().toISOString()};state.phase6={...(state.phase6||{}),cloudEnabled:true,lastCloudSync:new Date().toISOString(),lastCloudError:""};delete state.phase6.syncCompareLocalUpdatedAt;localStorage.setItem(STORE,JSON.stringify(state));return true;
 }catch(e){state.sync={status:"cloud-error",lastSyncedAt:state.sync?.lastSyncedAt||""};state.phase6={...(state.phase6||{}),lastCloudError:e.message||"Sync failed"};localStorage.setItem(STORE,JSON.stringify(state));return false}
}
async function cp6PasswordReset(){
 if(!cp6Ready())return toast("Cloud account is not configured.");
 const email=(document.getElementById("authEmail")?.value||"").trim();if(!email)return toast("Enter your email address first.");
 try{await cp6Request("/auth/v1/recover",{method:"POST",headers:{"apikey":CP6.config.auth.anonKey,"Content-Type":"application/json"},body:JSON.stringify({email,redirect_to:location.origin+location.pathname})});toast("If the account exists, a password reset email has been sent.")}
 catch(e){toast(e.message||"Could not request password reset.")}
}
async function cp6UpdatePassword(){
 const password=document.getElementById("authNewPassword")?.value||"";
 if(password.length<8)return toast("Choose a password with at least 8 characters.");
 try{await cp6Request("/auth/v1/user",{method:"PUT",headers:{"apikey":CP6.config.auth.anonKey,"Content-Type":"application/json"},body:JSON.stringify({password})});
  state.phase6={...(state.phase6||{}),recoveryMode:false,lastCloudError:""};CP6.token="";CP6.refreshToken="";localStorage.removeItem("careerpilot_phase6_session");state.account={signedIn:false,name:"",email:"",userId:""};state.sync={status:"local",lastSyncedAt:""};history.replaceState(null,"",location.pathname+location.search);save();toast("Password updated. Please sign in with your new password.");render();}
 catch(e){toast(e.message||"Could not update password. Request a new reset email.")}
}
async function cp6DeleteCloudData(){
 if(!CP6.token||!state.account?.userId)return toast("Sign in before deleting cloud data.");
 if(!confirm("Delete your CareerPilot cloud profile and daily logs? This cannot be undone. Your login account will remain, and this device's local copy will be kept."))return;
 try{const uid=encodeURIComponent(state.account.userId);await cp6Request(`/rest/v1/cp_daily_logs?user_id=eq.${uid}`,{method:"DELETE",headers:{Prefer:"return=minimal"}});await cp6Request(`/rest/v1/cp_profiles?user_id=eq.${uid}`,{method:"DELETE",headers:{Prefer:"return=minimal"}});state.sync={status:"local",lastSyncedAt:""};save();toast("Cloud profile and progress deleted. Local backup remains on this device.");render()}
 catch(e){toast(`Cloud deletion failed: ${e.message||"unknown error"}`)}
}
function save(){try{state.version=DATA_VERSION;state.deviceId=state.deviceId||newId();state.updatedAt=new Date().toISOString();localStorage.setItem(STORE,JSON.stringify(state));if(CP6?.token&&cp6Ready()){clearTimeout(CP6.syncTimer);CP6.syncTimer=setTimeout(()=>cp6Sync(false),700)}}catch(e){toast("Could not save changes on this device")}}
async function cp6AdminLoad(){ return []; }
function cp6Admin(){
 layout(`<section class="card premium-hero"><div class="premium-badge">✦ CAREERPILOT</div><h2>Customer progress is private</h2><p class="muted">This build does not provide an in-app customer-progress dashboard. Premium Coach tasks and reflections stay in the customer's own experience.</p><button class="btn" onclick="go('profile')">Back to profile →</button></section>`,"profile");
}
function authCard(){
 const cloud=cp6Ready();return `<section class="card account-card"><div class="eyebrow">CAREERPILOT ACCOUNT</div><h2>${state.phase6?.recoveryMode?"Set a new password":state.account?.signedIn?`Welcome, ${esc(state.account.name)}`:"Create or sign in to a real account"}</h2>${state.phase6?.recoveryMode?`<p class="muted">Choose a new password for your CareerPilot account.</p><input id="authNewPassword" class="field" type="password" minlength="8" autocomplete="new-password" placeholder="New password (8+ characters)"><button class="btn" onclick="cp6UpdatePassword()">Update password</button>`:state.account?.signedIn?`<p class="muted">${esc(state.account.email)}</p><div class="statusline"><span>Cloud sync</span><b>${state.sync?.status==="synced"?"Synced":"Connected"}</b></div><div class="statusline"><span>Last sync</span><b>${state.sync?.lastSyncedAt?new Date(state.sync.lastSyncedAt).toLocaleString():"Not synced yet"}</b></div><div class="row"><button class="btn" onclick="cp6Sync(true).then(()=>render())">Sync now</button><button class="btn secondary" onclick="cp6SignOut()">Sign out</button></div>${state.phase6?.lastCloudError?`<p class="small">${esc(state.phase6.lastCloudError)}</p>`:""}<button class="btn secondary" onclick="cp6DeleteCloudData()">Delete my cloud data</button>`:`<p class="muted">${cloud?"Your account can sync your assessment, career plan and Coach tasks across devices.":"Cloud is not configured yet; the app will continue working locally."}</p><div class="form-grid"><input id="authName" class="field" placeholder="Name" autocomplete="name"><input id="authEmail" class="field" type="email" placeholder="Email" autocomplete="email"><input id="authPassword" class="field" type="password" placeholder="Password (6+ characters)" autocomplete="new-password"></div><div class="row"><button class="btn" onclick="cp6Auth('signup')">Create cloud account</button><button class="btn secondary" onclick="cp6Auth('signin')">Sign in</button></div><button class="btn secondary" type="button" onclick="cp6PasswordReset()">Forgot password?</button>`}</section>`;
}
function profile(){
 const c=topCareer(),premium=premiumActive(),acct=state.account||{};const premiumStatus=premium?(state.premium.plan==="trial"?"Trial • "+trialLabel():"Premium"):"Free";
 layout(authCard()+`<div class="card"><div class="eyebrow">YOUR PROFILE</div><h2>CareerPilot settings</h2>${c?`<div class="mini-dashboard"><div><b>${esc(c.name)}</b><span class="small">Primary direction</span></div><div class="ring">${c.score}%</div></div>`:`<p class="muted">No assessment completed yet.</p>`}<div class="statgrid three"><div class="stat"><b>${state.results.length?"1":"0"}</b><span>Assessment</span></div><div class="stat"><b>${premiumStatus}</b><span>Plan</span></div><div class="stat"><b>${state.sync?.status==="synced"?"Cloud":"Local"}</b><span>Data</span></div></div></div>
 <div class="card section"><h3>Data & privacy</h3><p class="muted">Your device keeps a local copy. When cloud is configured and you sign in, the account can sync your CareerPilot data.</p><div class="row"><button class="btn secondary" onclick="exportData()">Export my data</button><button class="btn secondary" onclick="triggerImport()">Restore backup</button></div><input id="importFile" type="file" accept=".json,application/json" class="hide" onchange="importData(event)"></div>
 <div class="card section"><h3>Premium</h3><div class="statusline"><span>Current plan</span><b>${premiumStatus}</b></div><div class="statusline"><span>Entitlement source</span><b>${state.premium?.source||"Local trial"}</b></div><p class="small">Paid Premium should be granted only by a verified server billing webhook in production.</p><button class="btn" onclick="go('premium')">Open Premium →</button></div>`,`profile`);
}
function premiumActive(){
 const p=state.premium||{};
 if(p.plan==="premium")return !!p.active&&p.source==="server";
 if(p.plan==="trial"){const valid=p.trialEnds&&new Date(p.trialEnds)>new Date();if(valid){if(!p.active){state.premium={...p,active:true};save()}return true}state.premium={active:false,plan:"free",trialEnds:"",source:"local"};save();return false}
 return false;
}
function startTrial(){if(state.premium?.plan==="trial"&&state.premium?.trialEnds&&new Date(state.premium.trialEnds)>new Date())return go("premium");const end=new Date(Date.now()+3*86400000).toISOString();state.premium={active:true,plan:"trial",trialEnds:end,source:"local"};save();toast("3-day Premium trial started");go("premium")}
async function phase6Boot(){
 await cp6LoadConfig();state.phase6=state.phase6||{};state.phase6.cloudEnabled=cp6Ready();
 if(CP6.token&&CP6.refreshToken&&state.account?.signedIn){
  try{await cp6RefreshSession();await cp6Sync(true)}
  catch(e){CP6.token="";CP6.refreshToken="";localStorage.removeItem("careerpilot_phase6_session");state.account={signedIn:false,name:"",email:"",userId:""};state.sync={status:"local",lastSyncedAt:""};state.phase6.lastCloudError="Your session expired. Sign in again to sync. Local data is still available.";save()}
 }
 render();
}
function render(){load();const routes={home,assessment,dashboard,roadmap,coach,premium:coach,profile,career,matches,skills,admin:cp6Admin};(routes[state.screen]||home)()}
render();mobileAppInit();phase6Boot();
