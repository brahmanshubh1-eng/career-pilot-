# CareerPilot Phase A test report

Date: 2026-10-09

## Automated checks completed
- JavaScript syntax check: `app.js` — passed.
- JavaScript syntax check: `sw.js` — passed.
- JavaScript syntax check: `api/coach.js` — passed.
- Static checks for password reset, session refresh, cloud profile read/upsert, daily-log read/upsert, and owner-only cloud-data deletion — passed.
- SQL policy/trigger presence and ordering checks — passed.
- Frontend config scan for a Supabase service-role key — passed (none found).
- ZIP integrity check — passed after packaging.

## Not verified
- Live Supabase email signup/confirmation, login, session refresh, password reset, or two-device sync.
- SQL execution against the user's live Supabase project.
- Interactive browser/mobile testing. A headless Chromium smoke test was attempted, but the browser process timed out in this environment before producing a DOM; this is an environment limitation, not a successful test.
- Vercel Preview deployment. Vercel previously returned a 403 team-scope authorization error.

## Required before relying on cloud sync
Run `supabase-schema.sql` in the correct Supabase project's SQL Editor; configure Auth Email and Site URL/Redirect URLs; then deploy to a Vercel Preview and verify the flows with a test account. Until that is done, local device storage remains the fallback.
